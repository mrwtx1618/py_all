rm nba-data.csv
scrapy crawl nba_lottery -o nba-data.csv -t csv
